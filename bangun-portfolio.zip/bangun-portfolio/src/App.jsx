import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-blue-100 p-8 text-gray-900 font-sans">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-blue-700">Bangun Suryadi</h1>
        <p className="text-lg mt-2">Engineer | Planning & Performance | Operational Excellence</p>
        <a href="mailto:bangunsuryadi0210@gmail.com" className="text-blue-600 underline">bangunsuryadi0210@gmail.com</a> | 
        <a href="https://www.linkedin.com/in/bangun-suryadi-09aa00b0/" className="text-blue-600 underline ml-2" target="_blank">LinkedIn</a>
      </header>
      <section className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">Tentang Saya</h2>
        <p className="mb-6">
          Engineer muda dengan semangat tinggi dan pengalaman di industri minyak dan gas sejak 2018. 
          Fokus pada optimasi operasi, keselamatan kerja, dan kolaborasi tim lintas fungsi. 
          Siap untuk terus berkembang dan memberikan kontribusi terbaik.
        </p>
        <h2 className="text-2xl font-semibold mb-4">Keahlian</h2>
        <ul className="list-disc list-inside mb-6">
          <li>Engineering Problem Solving, PLC & DCS, PI System</li>
          <li>Fuzzy Logic, Digitalization Projects, Operational Optimization</li>
          <li>Team Collaboration, Communication, Safety Awareness</li>
        </ul>
        <h2 className="text-2xl font-semibold mb-4">Kontak</h2>
        <p>Email: bangunsuryadi0210@gmail.com</p>
        <p>LinkedIn: <a href="https://www.linkedin.com/in/bangun-suryadi-09aa00b0/" className="underline text-blue-600">Profile</a></p>
      </section>
    </div>
  );
}